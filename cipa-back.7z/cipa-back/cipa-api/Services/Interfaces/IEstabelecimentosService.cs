using CipaApi.Models;

namespace CipaApi.Services.Interfaces {
    public interface IEstabelecimentosService: ICrudService<Estabelecimento>
    {
        
    }
}