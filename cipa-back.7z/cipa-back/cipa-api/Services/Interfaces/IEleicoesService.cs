using CipaApi.Models;

namespace CipaApi.Services.Interfaces {
    public interface IEleicoesService: ICrudService<Eleicao>
    {
        
    }
}