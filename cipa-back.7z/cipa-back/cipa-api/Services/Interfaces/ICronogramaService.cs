using CipaApi.Models;

namespace CipaApi.Services.Interfaces {
    public interface ICronogramaService: ICrudService<EtapaCronograma>
    {
        
    }
}