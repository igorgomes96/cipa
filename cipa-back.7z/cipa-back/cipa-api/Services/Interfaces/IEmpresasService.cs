using CipaApi.Models;

namespace CipaApi.Services.Interfaces {
    public interface IEmpresasService: ICrudService<Empresa>
    {
        
    }
}