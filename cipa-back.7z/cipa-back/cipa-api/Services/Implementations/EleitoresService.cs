using CipaApi.Models;
using CipaApi.Services.Interfaces;

namespace CipaApi.Services.Implementations {
    public class EleitoresService: CrudService<Eleitor>, IEleitoresService {
        public EleitoresService(Context db): base(db) { }
    }
}