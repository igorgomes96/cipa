using CipaApi.Models;
using CipaApi.Services.Interfaces;

namespace CipaApi.Services.Implementations {
    public class EmpresasService: CrudService<Empresa>, IEmpresasService {
        public EmpresasService(Context db): base(db) { }
    }
}