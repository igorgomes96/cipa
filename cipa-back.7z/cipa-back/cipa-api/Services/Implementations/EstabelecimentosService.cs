using CipaApi.Models;
using CipaApi.Services.Interfaces;

namespace CipaApi.Services.Implementations {
    public class EstabelecimentosService: CrudService<Estabelecimento>, IEstabelecimentosService {
        public EstabelecimentosService(Context db): base(db) { }
    }
}