using CipaApi.Models;
using CipaApi.Services.Interfaces;

namespace CipaApi.Services.Implementations {
    public class CronogramaService: CrudService<EtapaCronograma>, ICronogramaService {
        public CronogramaService(Context db): base(db) { }
    }
}