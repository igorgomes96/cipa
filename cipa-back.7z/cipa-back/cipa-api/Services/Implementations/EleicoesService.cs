using CipaApi.Models;
using CipaApi.Services.Interfaces;

namespace CipaApi.Services.Implementations {
    public class EleicoesService: CrudService<Eleicao>, IEleicoesService {
        public EleicoesService(Context db): base(db) { }
    }
}