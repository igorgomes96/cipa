namespace CipaApi.Models {
    public class EtapaObrigatoria {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public int Ordem { get; set; }
    }
}