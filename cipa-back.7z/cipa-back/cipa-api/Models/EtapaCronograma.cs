using System;

namespace CipaApi.Models {
    public enum PosicaoEtapa {
        Passada,
        Atual,
        Futura
    }

    public class EtapaCronograma {
        public int Id { get; set; }
        public int EleicaoId { get; set; }
        public string NomeEtapa { get; set; }
        public string DescricaoEtapa { get; set; }
        public DateTime DataPrevista { get; set; }
        public DateTime DataRealizada { get; set; }
        public int EtapaObrigatoriaId { get; set; }
        public PosicaoEtapa PosicaoEtapa { get; set; }

        public EtapaObrigatoria EtapaObrigatoria { get; set; }
    }
}
