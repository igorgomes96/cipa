namespace CipaApi.Models {
    public class Estabelecimento {
        public int Id { get; set; }
        public int EmpresaId { get; set; }
        public string Cidade { get; set; }
        public string Endereco { get; set; }
        public string Descricao { get; set; }

        public Empresa Empresa { get; set; } 
    }
}