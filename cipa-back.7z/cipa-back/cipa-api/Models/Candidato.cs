using System.Collections.Generic;

namespace CipaApi.Models {
    public enum StatusAprovacao {
        Pendente,
        Aprovada,
        Reprovada
    }
    
    public class Candidato {
        public int Id { get; set; }
        public int Votos { get; set; }
        public StatusAprovacao StatusAprovacao { get; set; }
        public int EleitorId { get; set; }

        public Eleitor Eleitor { get; set; }
        public ICollection<Reprovacao> Reprovacoes { get; set; }
    }
}