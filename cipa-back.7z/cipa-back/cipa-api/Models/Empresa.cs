namespace CipaApi.Models {
    public class Empresa {
        public int Id { get; set; }
        public string RazaoSocial { get; set; }
        public string InformacoesGerais { get; set; }
        
    }
}