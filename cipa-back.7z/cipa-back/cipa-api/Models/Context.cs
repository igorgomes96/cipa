using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CipaApi.Models;

namespace CipaApi.Models
{
    public class Context : DbContext
    {

        public Context(DbContextOptions<Context> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            /*modelBuilder.Entity<ItemLitigio>()
                .HasOne(a => a.PlanoAcao)
                .WithOne(b => b.ItemLitigio)
                .HasForeignKey<PlanoAcao>(b => b.ItemLitigioId);

            modelBuilder.Entity<Empresa>()
                .HasIndex(e => e.Nome);

            var cascadeFKs = modelBuilder.Model.GetEntityTypes()
                .SelectMany(t => t.GetForeignKeys())
                .Where(fk => !fk.IsOwnership && fk.DeleteBehavior == DeleteBehavior.Cascade);

            foreach (var fk in cascadeFKs)
                fk.DeleteBehavior = DeleteBehavior.Restrict; */

            base.OnModelCreating(modelBuilder);
        }

        public virtual DbSet<Eleicao> Eleicoes { get; set; }
        public virtual DbSet<Eleitor> Eleitores { get; set; }
        public virtual DbSet<Candidato> Candidatos { get; set; }
        public virtual DbSet<Reprovacao> Reprovacoes { get; set; }
        public virtual DbSet<Empresa> Empresas { get; set; }
        public virtual DbSet<Estabelecimento> Estabelecimentos { get; set; }
        public virtual DbSet<EtapaObrigatoria> EtapasObrigatorias { get; set; }
        public virtual DbSet<EtapaCronograma> EtapasCronogramas { get; set; }
        

    }
}
