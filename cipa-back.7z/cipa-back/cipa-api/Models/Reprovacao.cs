using System;

namespace CipaApi.Models {
    public class Reprovacao {
        public int Id { get; set; }
        public int CandidatoId { get; set; }
        public string MotivoReprovacao { get; set; }
        public DateTime Horario { get; set; }

        public Candidato Candidato { get; set; }
    }
}