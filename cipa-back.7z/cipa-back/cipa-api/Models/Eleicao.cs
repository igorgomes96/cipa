
namespace CipaApi.Models
{
    public class Eleicao
    {
        public int Id { get; set; }
        public int Gestao { get; set; }
        public int DuracaoGestao { get; set; }
        public int EstabelecimentoId { get; set; }

        public Estabelecimento Estabelecimento { get; set; }

    }

}