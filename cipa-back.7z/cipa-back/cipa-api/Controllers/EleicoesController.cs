using System.Collections.Generic;
using System.Linq;
using CipaApi.Models;
using CipaApi.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace CipaApi.Controllers {
    [Route("api/[controller]")]
    [ApiController]
    public class EleicoesController: ControllerBase {
        
        private readonly IEleicoesService _eleicoesService;

        public EleicoesController(IEleicoesService eleicoesService) {
            _eleicoesService = eleicoesService;
        }
        [HttpGet]
        public IQueryable<Eleicao> Get() => this._eleicoesService.Query();

        [HttpGet("{id}")]
        public ActionResult<Eleicao> Get(int id) {
            Eleicao eleicao = this._eleicoesService.Find(id);
            if (eleicao == null) {
                return NotFound("Eleição não encontrada!");
            } else {
                return Ok(eleicao);
            }
        }

        [HttpPost]
        public ActionResult<Eleicao> Post(Eleicao eleicao) => this._eleicoesService.Add(eleicao);

        [HttpPut("{id}")]
        public ActionResult Put(int id, Eleicao eleicao) {
            this._eleicoesService.Update(eleicao, id);
            return NoContent();
        }

        public ActionResult<Eleicao> Delete(int id) => this._eleicoesService.Delete(id);

    }
}