﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CipaApi.Middleware;
using CipaApi.Models;
using CipaApi.Services.Implementations;
using CipaApi.Services.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CipaApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddDbContext<Context>(opt => {
                opt.UseInMemoryDatabase("cipa");
            });

            services.AddScoped(typeof(ICrudService<>), typeof(CrudService<>));
            services.AddScoped<IEleicoesService, EleicoesService>();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, Context context)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpErrorMiddleware();

            Seed(context);
            app.UseHttpsRedirection();
            app.UseMvc();
        }

        private void Seed(Context context) {
            List<Eleicao> eleicoes = new List<Eleicao> {
                new Eleicao {
                    Gestao = 1,
                    DuracaoGestao = 2
                },
                new Eleicao {
                    Gestao = 2,
                    DuracaoGestao = 2
                }
            };

            context.Eleicoes.AddRange(eleicoes);
            context.SaveChanges();
        }
    }
}
